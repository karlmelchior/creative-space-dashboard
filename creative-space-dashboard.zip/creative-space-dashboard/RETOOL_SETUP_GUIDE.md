# 🎨 Retool Setup - Quick Visual Guide

Dette er en hurtig guide til at komme i gang med Retool efter du har deployed backend.

## 🎯 Mål

Lave et dashboard der ligner jeres Power BI dashboard med Creative Space branding.

---

## Step 1: Opret Første App

1. Login på retool.com
2. Klik "Create new" → "App"
3. Navngiv: "Creative Space Dashboard"

---

## Step 2: Tilføj API Resource

### I Retool:
1. Nederst i venstre sidebar → "Resources"
2. "+ Create new" → "REST API"
3. Navngiv: "Creative Space API"
4. Base URL: `https://your-railway-url.railway.app`
5. Headers: Ingen nødvendige
6. Save

---

## Step 3: Byg Layout

### Topbar med Logo

**Component:** Container
- Background: #fffbf8 (off-white)
- Height: 80px

**Inside container:**
- Image component → Upload Creative Space logo
- Text: "CREATIVE SPACE DASHBOARD" (GTHaptik Bold, #3d3b3b)

### Dato Vælgere

**Component:** Date Range Picker × 2
1. `dateRange`:
   - Label: "Dato interval"
   - Default: Last 7 days

2. `benchmarkDateRange`:
   - Label: "Benchmark dato interval"
   - Default: Same period last year

---

## Step 4: Første Metric - PAX Summary

### Query Setup

**Ny Query:**
- Name: `getPaxSummary`
- Resource: Creative Space API
- Method: GET
- URL: `/api/pax/summary`
- Query Params:
  ```javascript
  start_date: {{ moment(dateRange.value.start).format('YYYY-MM-DD') }}
  end_date: {{ moment(dateRange.value.end).format('YYYY-MM-DD') }}
  benchmark_start: {{ moment(benchmarkDateRange.value.start).format('YYYY-MM-DD') }}
  benchmark_end: {{ moment(benchmarkDateRange.value.end).format('YYYY-MM-DD') }}
  ```
- Run on page load: ✅

### Visual Component

**Component:** Statistic
- Value: `{{ getPaxSummary.data.current_pax }}`
- Label: "PAX"
- Description: 
  ```javascript
  {{ getPaxSummary.data.benchmark_pax }} benchmark
  {{ getPaxSummary.data.change_percent > 0 ? '▲' : '▼' }}
  {{ Math.abs(getPaxSummary.data.change_percent).toFixed(1) }}%
  ```
- Primary color: #ec6907 (orange)
- Font: GTHaptik

---

## Step 5: PAX Bar Chart

### Query

**Ny Query:**
- Name: `getPaxByDepartment`
- Resource: Creative Space API  
- Method: GET
- URL: `/api/pax/by-department`
- Query Params: (same as above)

### Chart Component

**Component:** Chart
- Type: Bar Chart
- Data source: `{{ getPaxByDepartment.data }}`

**X-Axis:**
- Data key: `department`
- Label: "Afdeling"

**Y-Axis (Current):**
- Data key: `current_pax`
- Label: "PAX"
- Color: #ec6907 (orange)

**Y-Axis (Benchmark):**
- Data key: `benchmark_pax`
- Label: "Benchmark"
- Color: #dadfda (light gray)

**Styling:**
- Background: #fffbf8
- Grid color: #c6d1c7

---

## Step 6: Belægningsgrad Table

### Query

**Ny Query:**
- Name: `getOccupancyByDept`
- Resource: Creative Space API
- Method: GET
- URL: `/api/occupancy/by-department`
- Query Params: (same as above)

### Table Component

**Component:** Table
- Data source: `{{ getOccupancyByDept.data }}`

**Columns:**
1. Department (department)
2. Nuværende (current_rate) - Format: `{{ item }}%`
3. Benchmark (benchmark_rate) - Format: `{{ item }}%`  
4. Ændring (change_points) - Format: `{{ item > 0 ? '+' : '' }}{{ item }}%-point`

**Conditional formatting:**
- change_points > 0 → Green background (#c6d1c7)
- change_points < 0 → Red tint

---

## Step 7: Lønudgifter Cards

### Query

**Ny Query:**
- Name: `getLaborSummary`
- Resource: Creative Space API
- Method: GET
- URL: `/api/labor/summary`
- Query Params: (same as above)

### Statistics Grid

**Layout:** 3 kolonner

**Card 1: Lønudgifter**
- Value: `{{ getLaborSummary.data.current_cost.toLocaleString() }} kr`
- Benchmark: `{{ getLaborSummary.data.benchmark_cost.toLocaleString() }} kr`
- Change: `{{ getLaborSummary.data.change_percent.toFixed(1) }}%`

**Card 2: Timer**
- Value: `{{ getLaborSummary.data.current_hours }}`
- Benchmark: `{{ getLaborSummary.data.benchmark_hours }}`

**Card 3: Løn per PAX**
- Value: Beregn fra labor / pax
- Use query: `getLaborVsPax`

---

## Step 8: Heatmap (Belægningsgrad per Tid)

### Query

**Ny Query:**
- Name: `getOccupancyByCategory`
- Resource: Creative Space API
- Method: GET
- URL: `/api/occupancy/by-category`
- Query Params: dateRange only (ikke benchmark)

### Heatmap Component

**Option 1: Custom Component med JavaScript**
```javascript
// Transform data for heatmap
const categories = ['Formiddag', 'Tidlig eftermiddag', 'Eftermiddag', 'Aften'];
const weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

const heatmapData = categories.map(cat => {
  const row = { category: cat };
  weekdays.forEach(day => {
    const dataPoint = getOccupancyByCategory.data.find(
      d => d.category === cat && d.weekday === day
    );
    row[day] = dataPoint ? dataPoint.occupancy_rate : 0;
  });
  return row;
});

return heatmapData;
```

**Option 2: Brug Table med Conditional Formatting**
- Columns: Kategori, Mon, Tue, Wed, Thu, Fri, Sat, Sun
- Cell colors baseret på værdi:
  - > 80%: Dark orange (#ec6907)
  - 60-80%: Light orange (#ffe4d6)
  - < 60%: Light gray (#dadfda)

---

## Step 9: Export til CSV

### Button Component

**Component:** Button
- Text: "📥 Eksporter til CSV"
- Color: #ec6907

**Event Handler:**
```javascript
// On click
utils.downloadFile(
  getPaxByDepartment.data,
  `pax-data-${moment().format('YYYY-MM-DD')}.csv`,
  'csv'
);
```

---

## Step 10: Styling & Branding

### Global Styling

**I App Settings:**
- Primary color: #ec6907
- Background: #fffbf8
- Text color: #3d3b3b
- Font family: (Upload GTHaptik hvis muligt, eller brug "Inter")

### Container Styling

**Header Container:**
- Background: #fffbf8
- Border bottom: 2px solid #c6d1c7
- Padding: 20px

**Metric Cards:**
- Background: White
- Border: 1px solid #c6d1c7
- Border radius: 8px
- Box shadow: Subtle

**Charts:**
- Background: White
- Grid color: #e0e0e0
- Orange bars: #ec6907
- Gray bars: #dadfda

---

## Step 11: Responsive Layout

**Retool Grid System:**
- Desktop: 12 kolonne grid
- Tablet: Auto-collapse
- Mobile: Stack vertically

**Layout Anbefaling:**
```
┌─────────────────────────────────┐
│  Logo + Title                    │ (Full width)
├──────────┬──────────────────────┤
│ Date     │ Benchmark Date       │ (6 cols each)
├──────────┴──────────────────────┤
│ PAX Card │ Occ Card │ Labor Card│ (4 cols each)
├─────────────────────────────────┤
│ PAX Bar Chart                    │ (Full width)
├─────────────────────────────────┤
│ Occupancy Heatmap                │ (Full width)
├─────────────────────────────────┤
│ Labor Table                      │ (Full width)
└─────────────────────────────────┘
```

---

## Step 12: Auto-refresh

**I Query Settings:**
- Enable "Run query on page load": ✅
- Enable "Refresh on window focus": ✅
- Optional: "Run query periodically" → Every 5 minutes

---

## 🎨 Farve Reference

Gem disse som Retool theme colors:

```
Primary (Orange):    #ec6907
Dark Gray (Text):    #3d3b3b
Light Beige:         #ffe4d6
Sage Green:          #c6d1c7
Off-White (BG):      #fffbf8
Light Gray:          #dadfda
```

---

## 📱 Testing Checklist

- [ ] Dato vælgere opdaterer alle queries
- [ ] Benchmark sammenligninger vises korrekt
- [ ] Alle afdelinger vises (6 stk)
- [ ] Farver matcher Creative Space branding
- [ ] CSV export virker
- [ ] Responsive på mobil/tablet
- [ ] Logo vises korrekt
- [ ] Tal formateres med tusind-seperatorer (DKK)

---

## 🚀 Gå Live

1. Test grundigt
2. Inviter teammedlemmer via Retool settings
3. Sæt permissions (View/Edit)
4. Del link eller embed i jeres interne portal

---

**Done! 🎉**

Du har nu et professionelt dashboard med Creative Space branding og live data fra Snowflake!
