# Creative Space Dashboard API - Endpoint Documentation

Base URL: `https://your-railway-url.railway.app`

## 🏥 Health Check

### GET `/api/health`
Check om API og database forbindelse virker.

**Response:**
```json
{
  "status": "healthy",
  "database": "connected",
  "timestamp": "2025-02-09 10:30:00"
}
```

---

## 👥 PAX (Gæster) Endpoints

### GET `/api/pax/by-department`
Hent PAX per afdeling med benchmark sammenligning.

**Query Parameters:**
- `start_date` (required): YYYY-MM-DD
- `end_date` (required): YYYY-MM-DD
- `benchmark_start` (required): YYYY-MM-DD
- `benchmark_end` (required): YYYY-MM-DD

**Example:**
```
/api/pax/by-department?start_date=2025-02-08&end_date=2025-02-16&benchmark_start=2022-01-12&benchmark_end=2024-12-31
```

**Response:**
```json
[
  {
    "department": "Frederiksberg",
    "current_pax": 1758,
    "benchmark_pax": 46668,
    "change_percent": -96.23
  },
  {
    "department": "Lyngby",
    "current_pax": 1833,
    "benchmark_pax": 34204,
    "change_percent": -94.64
  }
]
```

### GET `/api/pax/summary`
Hent samlet PAX summary med benchmark.

**Query Parameters:**
- `start_date`, `end_date`, `benchmark_start`, `benchmark_end`

**Response:**
```json
{
  "current_pax": 8901,
  "benchmark_pax": 190241,
  "change_percent": -95.32,
  "current_bookings": 2150,
  "benchmark_bookings": 45000
}
```

---

## 📊 Belægningsgrad Endpoints

### GET `/api/occupancy/by-department`
Hent belægningsgrad per afdeling.

**Query Parameters:**
- `start_date`, `end_date`, `benchmark_start`, `benchmark_end`

**Response:**
```json
[
  {
    "department": "Østerbro",
    "current_rate": 81.79,
    "benchmark_rate": 20.4,
    "change_points": 61.39
  }
]
```

### GET `/api/occupancy/by-category`
Hent belægningsgrad per tidskategori og ugedag (heatmap data).

**Query Parameters:**
- `start_date`, `end_date`

**Response:**
```json
[
  {
    "category": "Formiddag",
    "weekday": "Mon",
    "occupancy_rate": 86.3
  },
  {
    "category": "Formiddag",
    "weekday": "Tue",
    "occupancy_rate": 81.0
  }
]
```

---

## 💰 Lønudgifter Endpoints

### GET `/api/labor/by-department`
Hent lønudgifter per afdeling med benchmark.

**Query Parameters:**
- `start_date`, `end_date`, `benchmark_start`, `benchmark_end`

**Response:**
```json
[
  {
    "department": "Frederiksberg",
    "current_cost": 58705.0,
    "benchmark_cost": 4217014.0,
    "current_hours": 3500,
    "employee_count": 25,
    "change_percent": -98.61
  }
]
```

### GET `/api/labor/summary`
Hent samlet lønudgifter summary.

**Query Parameters:**
- `start_date`, `end_date`, `benchmark_start`, `benchmark_end`

**Response:**
```json
{
  "current_cost": 312352.0,
  "benchmark_cost": 19446434.0,
  "current_hours": 18500,
  "benchmark_hours": 1150000,
  "change_percent": -98.39
}
```

---

## 📈 Kombinerede Metrics

### GET `/api/metrics/revenue-vs-pax`
Hent omsætning vs PAX per afdeling.

**Query Parameters:**
- `start_date`, `end_date`

**Response:**
```json
[
  {
    "department": "Frederiksberg",
    "pax": 1758,
    "revenue": 0,
    "revenue_per_pax": 0
  }
]
```

**NOTE:** Revenue felter er PLACEHOLDER - skal opdateres med rigtig omsætningsdata.

### GET `/api/metrics/labor-vs-revenue`
Hent løn vs omsætning ratio per afdeling.

**Query Parameters:**
- `start_date`, `end_date`

**Response:**
```json
[
  {
    "department": "Frederiksberg",
    "labor_cost": 58705.0,
    "revenue": 0,
    "labor_percentage": 0
  }
]
```

**NOTE:** Revenue felter er PLACEHOLDER.

### GET `/api/metrics/labor-vs-pax`
Hent løn per PAX med benchmark.

**Query Parameters:**
- `start_date`, `end_date`, `benchmark_start`, `benchmark_end`

**Response:**
```json
[
  {
    "department": "Frederiksberg",
    "current_labor_per_pax": 33.39,
    "benchmark_labor_per_pax": 90.36,
    "change_percent": -63.05
  }
]
```

---

## 🏢 Reference Data

### GET `/api/departments`
Hent liste over alle afdelinger.

**Response:**
```json
[
  "Aarhus",
  "Frederiksberg",
  "Lyngby",
  "Odense",
  "Vejle",
  "Østerbro"
]
```

---

## 📥 Export

### POST `/api/export/csv`
Export data til CSV format.

**Body:**
```json
{
  "endpoint": "/api/pax/by-department",
  "params": {
    "start_date": "2025-02-08",
    "end_date": "2025-02-16"
  }
}
```

**Response:**
CSV file download

---

## 🔧 Brug i Retool

### Eksempel: PAX Query i Retool

1. Opret ny query
2. Vælg "Creative Space API" resource
3. **Method:** GET
4. **URL path:** `/api/pax/by-department`
5. **Query params:**
   ```
   start_date: {{ dateRange.value.start }}
   end_date: {{ dateRange.value.end }}
   benchmark_start: {{ benchmarkDateRange.value.start }}
   benchmark_end: {{ benchmarkDateRange.value.end }}
   ```

### Eksempel: Vis Data i Table

```javascript
// Data source
{{ getPaxByDepartment.data }}

// Columns
department | current_pax | benchmark_pax | change_percent
```

### Eksempel: Bar Chart

```javascript
// Data
{{ getPaxByDepartment.data }}

// X-axis
department

// Y-axis values
current_pax (color: #ec6907)
benchmark_pax (color: #dadfda)
```

---

## ⚠️ Vigtige Noter

### Dato Formater
Alle datoer skal være i format: `YYYY-MM-DD`

Eksempel: `2025-02-09`

### Omsætning Data
Følgende endpoints har PLACEHOLDER data og skal opdateres:
- `/api/revenue/by-department`
- `/api/metrics/revenue-vs-pax`
- `/api/metrics/labor-vs-revenue`

Find den korrekte sales tabel i Snowflake og opdater queries i `app.py`.

### Error Handling
Alle endpoints returnerer standard HTTP status codes:
- `200` - Success
- `500` - Server error (check logs)

Error response format:
```json
{
  "error": "Error message here"
}
```

### Rate Limiting
Ingen rate limiting implementeret endnu. Overvej at tilføje hvis der kommer meget trafik.

### CORS
CORS er enabled for alle origins. I produktion bør du begrænse dette til kun Retool's domæne.

---

## 🚀 Testing Endpoints

### Test med cURL

```bash
# Health check
curl https://your-url.railway.app/api/health

# PAX by department
curl "https://your-url.railway.app/api/pax/by-department?start_date=2025-02-08&end_date=2025-02-16&benchmark_start=2022-01-12&benchmark_end=2024-12-31"

# Departments list
curl https://your-url.railway.app/api/departments
```

### Test med Browser

Åbn direkte i browser:
```
https://your-url.railway.app/api/health
https://your-url.railway.app/api/departments
```

---

## 📝 Changelog

### Version 1.0 (2025-02-09)
- Initial release
- All core endpoints implemented
- PAX, occupancy, labor endpoints
- Benchmark comparisons
- Department filtering
- CSV export capability

### TODO / Future Improvements
- [ ] Opdater revenue endpoints med rigtig data
- [ ] Tilføj caching for bedre performance
- [ ] Implementer rate limiting
- [ ] Tilføj authentication
- [ ] Mere granular error messages
- [ ] Logging og monitoring
- [ ] Unit tests
