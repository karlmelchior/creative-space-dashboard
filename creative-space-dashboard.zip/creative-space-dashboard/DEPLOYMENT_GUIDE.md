# Creative Space Dashboard - Deployment Guide

## 📦 Hvad du har fået

Du har nu en komplet backend API der forbinder til jeres Snowflake database og leverer data til Retool.

**Backend API Endpoints:**
- `/api/health` - Check om API virker
- `/api/pax/by-department` - PAX per afdeling med benchmark
- `/api/pax/summary` - Samlet PAX summary
- `/api/occupancy/by-department` - Belægningsgrad per afdeling
- `/api/occupancy/by-category` - Belægningsgrad per tidskategori
- `/api/labor/by-department` - Lønudgifter per afdeling
- `/api/labor/summary` - Samlet lønudgifter
- `/api/labor/vs-pax` - Løn per PAX
- `/api/departments` - Liste over afdelinger
- Og flere...

---

## 🚀 STEP 1: Deploy Backend til Railway (10-15 min)

### 1.1 Opret Railway Konto

1. Gå til **https://railway.app**
2. Klik **"Login"** → **"Login with GitHub"**
3. Opret GitHub konto hvis du ikke har en (gratis)
4. Godkend Railway til at forbinde til GitHub

### 1.2 Opret Nyt Project

1. Klik **"New Project"**
2. Vælg **"Deploy from GitHub repo"**
3. Klik **"Configure GitHub App"**
4. Giv Railway adgang til dine repositories

### 1.3 Upload Backend Kode

**Option A - Via GitHub:**
1. Opret nyt repository på GitHub
2. Upload alle filer fra `backend/` mappen
3. I Railway: Vælg dit repository
4. Railway deployer automatisk

**Option B - Via Railway CLI:**
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# I backend mappen:
cd backend/
railway init
railway up
```

### 1.4 Tilføj Environment Variables

1. I Railway dashboard, klik på dit project
2. Gå til **"Variables"** tab
3. Tilføj følgende variabler:

```
SNOWFLAKE_USER=Karl_admin
SNOWFLAKE_PASSWORD=CSKode2022
FLASK_ENV=production
PORT=5000
```

4. Klik **"Save"**

### 1.5 Deploy & Test

1. Railway deployer automatisk efter du gemmer variables
2. Du får en URL som: `https://creative-space-dashboard-production.up.railway.app`
3. Test det: Åbn `https://DIN-URL/api/health` i browseren
4. Du skulle se: `{"status": "healthy", "database": "connected"}`

✅ **Backend er nu live!**

---

## 🎨 STEP 2: Opret Retool Dashboard (20-30 min)

### 2.1 Opret Retool Konto

1. Gå til **https://retool.com**
2. Klik **"Start building for free"**
3. Opret konto (brug arbejds-email)
4. Vælg **"Team"** plan når du er klar (første 14 dage er gratis trial)

### 2.2 Opret Ny App

1. Klik **"Create new"** → **"App"**
2. Navngiv den: **"Creative Space Dashboard"**
3. Du er nu i Retool's app builder

### 2.3 Tilføj Backend API som Resource

1. Klik **"Resources"** (venstre sidebar)
2. Klik **"Create new"** → **"REST API"**
3. Navngiv den: **"Creative Space API"**
4. **Base URL:** Indtast din Railway URL: `https://DIN-URL`
5. Klik **"Create resource"**

### 2.4 Test Forbindelsen

1. I Retool, tilføj en ny **Query**
2. Vælg **"Creative Space API"** som resource
3. **Method:** GET
4. **URL path:** `/api/health`
5. Klik **"Run"**
6. Du skulle se: `{"status": "healthy", "database": "connected"}`

✅ **Retool er nu forbundet til din backend!**

---

## 📊 STEP 3: Byg Dashboards i Retool

### 3.1 Tilføj Dato Vælgere

1. Drag **"Date Range"** component til canvas
2. Navngiv den: `dateRange`
3. Drag endnu en **"Date Range"**
4. Navngiv den: `benchmarkDateRange`
5. Sæt labels: "Dato interval" og "Benchmark dato interval"

### 3.2 Opret PAX Query

1. Klik **"+"** for ny query
2. Vælg **"Creative Space API"**
3. **Method:** GET
4. **URL path:** `/api/pax/by-department`
5. **Query params:**
   ```
   start_date: {{ dateRange.value.start }}
   end_date: {{ dateRange.value.end }}
   benchmark_start: {{ benchmarkDateRange.value.start }}
   benchmark_end: {{ benchmarkDateRange.value.end }}
   ```
6. Navngiv query: `getPaxByDepartment`
7. Klik **"Run"**

### 3.3 Tilføj PAX Summary Card

1. Drag **"Statistic"** component til canvas
2. **Value:** `{{ getPaxByDepartment.data[0].current_pax }}`
3. **Label:** "PAX"
4. **Prefix/Suffix:** Tilføj benchmark comparison
5. Brug **Creative Space farver:**
   - **Primary color:** #ec6907 (orange)
   - **Text color:** #3d3b3b (dark gray)
   - **Background:** #fffbf8 (off-white)

### 3.4 Tilføj PAX Bar Chart

1. Drag **"Chart"** component til canvas
2. **Chart type:** Bar
3. **Data source:** `{{ getPaxByDepartment.data }}`
4. **X-axis:** `department`
5. **Y-axis:** `current_pax` (orange #ec6907)
6. **Y-axis 2:** `benchmark_pax` (grå #dadfda)
7. Juster farver til Creative Space branding

### 3.5 Gentag for Andre Metrics

Opret tilsvarende queries og visualiseringer for:
- Belægningsgrad (`/api/occupancy/by-department`)
- Lønudgifter (`/api/labor/by-department`)
- Omsætning vs PAX (`/api/metrics/revenue-vs-pax`)
- Løn vs PAX (`/api/metrics/labor-vs-pax`)

### 3.6 Tilføj Creative Space Branding

1. Upload Creative Space logo (det cirkulære logo)
2. Tilføj **"Image"** component øverst
3. **Source:** Upload logoet
4. Tilføj **"Text"** component: **"CREATIVE SPACE"** med GTHaptik font

**Farvepalette:**
```
#3d3b3b - Mørk grå (tekst, headers)
#ffe4d6 - Lys beige (kort)
#c6d1c7 - Sage grøn (sektioner)
#ec6907 - Orange (CTA, aktuelle værdier)
#fffbf8 - Off-white (baggrund)
#dadfda - Lys grå (benchmark, borders)
```

### 3.7 Tilføj CSV Export

1. Drag **"Button"** component
2. **Label:** "Eksporter til CSV"
3. **Event handler:**
   ```javascript
   // Download data as CSV
   utils.downloadFile(
     getPaxByDepartment.data,
     'pax-data.csv',
     'csv'
   );
   ```

---

## 🎯 STEP 4: Test Alt Fungerer

### 4.1 Test Dato Filtrering

1. Vælg forskellige datoer i `dateRange`
2. Check at data opdateres
3. Sammenlign med benchmark periode

### 4.2 Test Alle Metrics

- ✅ PAX vises korrekt
- ✅ Belægningsgrad beregnes
- ✅ Lønudgifter summeres
- ✅ Benchmark sammenligninger vises

### 4.3 Test på Mobil

1. Retool har automatisk responsive design
2. Test på telefon/tablet
3. Juster layout hvis nødvendigt

---

## 💰 Omkostninger

**Railway (Backend Hosting):**
- **Free tier:** $5 credit/måned (nok til at starte)
- **Hobby plan:** $5/måned
- **Pro plan:** $20/måned (hvis I får meget trafik)

**Retool:**
- **Free trial:** 14 dage
- **Team plan:** $50/måned for 5 brugere
- **Business plan:** $50/bruger/måned

**Total:** ~$55-75/måned

---

## 🔧 Vedligeholdelse

### Opdater Backend Kode

1. Rediger filer lokalt
2. Push til GitHub
3. Railway deployer automatisk

### Tilføj Nye Endpoints

1. Rediger `app.py`
2. Tilføj nye routes
3. Deploy
4. Brug nye endpoints i Retool

### Overvåg Performance

1. Railway dashboard viser:
   - CPU usage
   - Memory usage
   - Request count
   - Error logs

---

## ⚠️ VIGTIGE NOTER

### Omsætning Data

Backend'en har **PLACEHOLDER** data for omsætning endpoints fordi jeg ikke kunne se præcis hvor jeres omsætningsdata ligger i Snowflake.

**Du skal opdatere disse queries:**
- `/api/revenue/by-department`
- `/api/metrics/revenue-vs-pax`
- `/api/metrics/labor-vs-revenue`

Find den rigtige tabel for salgsdata og erstat placeholder queries.

### Sikkerhed

**VIGTIGT:** I produktion bør du:
1. Skifte Snowflake password
2. Oprette read-only Snowflake bruger til API'en
3. Tilføje API authentication hvis nødvendigt
4. Bruge Railway's secret management

---

## 🆘 Troubleshooting

### Backend deployer ikke

- Check Railway logs
- Verificer environment variables er sat korrekt
- Check Snowflake credentials

### Retool kan ikke forbinde

- Verificer Railway URL er korrekt
- Test `/api/health` endpoint direkte i browser
- Check CORS er enabled (det er det i koden)

### Data ser forkert ud

- Check dato formater
- Verificer queries i `app.py`
- Test queries direkte i Snowflake

### Performance Issues

- Tilføj database indexes
- Implementer caching
- Optimer queries
- Overvej at upgrade Railway plan

---

## 📞 Næste Skridt

1. ✅ Deploy backend til Railway
2. ✅ Opret Retool konto
3. ✅ Forbind Retool til backend API
4. ✅ Byg dit første dashboard
5. ✅ Tilpas design til Creative Space branding
6. ✅ Inviter teammedlemmer
7. ✅ Opdater omsætning queries når du finder den rigtige tabel

**Held og lykke! 🚀**

Hvis du løber ind i problemer, check:
- Railway docs: https://docs.railway.app
- Retool docs: https://docs.retool.com
- Snowflake docs: https://docs.snowflake.com
