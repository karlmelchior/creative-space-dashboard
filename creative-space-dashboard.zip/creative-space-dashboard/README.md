# Creative Space Dashboard Backend

Backend API til Creative Space's Retool dashboard. Forbinder til Snowflake og leverer data om PAX, belægningsgrad, lønudgifter og mere.

## 🚀 Quick Start

### Hvad er dette?

Dette er backend API'en der:
- ✅ Forbinder til jeres Snowflake database
- ✅ Henter data om bookinger, gæster, personale, lønudgifter
- ✅ Beregner benchmarks og sammenligninger
- ✅ Leverer data til Retool dashboard via REST API

### Filer i dette projekt

```
creative-space-dashboard/
├── backend/
│   ├── app.py                  # Main API application
│   ├── requirements.txt        # Python dependencies
│   ├── Procfile               # Deployment configuration
│   ├── runtime.txt            # Python version
│   └── .env.example           # Environment variables template
├── DEPLOYMENT_GUIDE.md        # Step-by-step deployment guide (DANSK)
├── API_DOCUMENTATION.md       # Complete API reference
└── README.md                  # This file
```

## 📋 Prerequisites

- Python 3.11+
- Snowflake database access
- Railway account (for hosting)
- Retool account (for frontend)

## 🔧 Local Development

### 1. Install Dependencies

```bash
cd backend/
pip install -r requirements.txt
```

### 2. Set Environment Variables

```bash
cp .env.example .env
# Edit .env with your Snowflake credentials
```

### 3. Run Locally

```bash
python app.py
```

API will be available at `http://localhost:5000`

### 4. Test

```bash
curl http://localhost:5000/api/health
```

## 🌐 Deployment

Se **DEPLOYMENT_GUIDE.md** for komplet step-by-step guide på dansk.

### Quick Deploy til Railway

1. Push kode til GitHub
2. Gå til railway.app
3. "New Project" → "Deploy from GitHub"
4. Vælg repository
5. Tilføj environment variables
6. Deploy!

## 📊 API Endpoints

### Key Endpoints

- `GET /api/health` - Health check
- `GET /api/pax/by-department` - PAX per afdeling
- `GET /api/occupancy/by-department` - Belægningsgrad
- `GET /api/labor/by-department` - Lønudgifter
- `GET /api/departments` - Liste over afdelinger

Se **API_DOCUMENTATION.md** for komplet liste og eksempler.

## 🎨 Brug med Retool

1. Opret REST API resource i Retool
2. Base URL: `https://your-railway-url.railway.app`
3. Create queries til forskellige endpoints
4. Bind til components (charts, tables, etc.)

### Eksempel Query i Retool

```javascript
// Resource: Creative Space API
// Method: GET
// Path: /api/pax/by-department

// Query params:
{
  start_date: {{ dateRange.value.start }},
  end_date: {{ dateRange.value.end }},
  benchmark_start: {{ benchmarkDateRange.value.start }},
  benchmark_end: {{ benchmarkDateRange.value.end }}
}
```

## ⚙️ Configuration

### Environment Variables

```bash
SNOWFLAKE_USER=your_username
SNOWFLAKE_PASSWORD=your_password
FLASK_ENV=production
PORT=5000
```

### Snowflake Connection

API forbinder til:
- Account: `qp38588.west-europe.azure`
- Warehouse: `powerbi_wh`
- Databases: `PLANDAY`, `DINNERBOOKING`, `E_CONOMIC`

## 🔒 Security

### Anbefalinger til Produktion

1. **Opret read-only Snowflake user**
   ```sql
   CREATE USER dashboard_readonly PASSWORD='secure_password';
   GRANT USAGE ON WAREHOUSE powerbi_wh TO dashboard_readonly;
   -- Grant only SELECT permissions
   ```

2. **Brug Railway secrets** til credentials (ikke hardcoded)

3. **Begræns CORS** til kun Retool domæne

4. **Tilføj rate limiting** hvis nødvendigt

## ⚠️ Vigtige Noter

### Omsætning Data

Nogle endpoints har PLACEHOLDER data for omsætning fordi vi ikke kunne finde den præcise tabel:

```python
# Disse skal opdateres:
/api/revenue/by-department
/api/metrics/revenue-vs-pax
/api/metrics/labor-vs-revenue
```

Find den korrekte sales tabel i Snowflake og opdater queries i `app.py`.

### Dato Formater

Alle datoer skal være: `YYYY-MM-DD`

Eksempel: `2025-02-09`

## 📈 Monitoring

### Railway Dashboard

Check:
- CPU/Memory usage
- Request count
- Error logs
- Deployment status

### Health Check

Test regelmæssigt:
```bash
curl https://your-url.railway.app/api/health
```

## 🐛 Troubleshooting

### Backend starter ikke

1. Check Railway logs
2. Verificer environment variables
3. Test Snowflake credentials

### Ingen data returneres

1. Check Snowflake forbindelse
2. Verificer table names i queries
3. Check dato formater

### CORS errors i Retool

- CORS er enabled i koden
- Tjek at Railway URL er korrekt

## 📞 Support

### Ressourcer

- Railway docs: https://docs.railway.app
- Snowflake docs: https://docs.snowflake.com
- Flask docs: https://flask.palletsprojects.com
- Retool docs: https://docs.retool.com

### Logs

Railway logs:
```bash
railway logs
```

Eller check i Railway dashboard.

## 🔄 Updates

### Opdater Backend

1. Rediger filer lokalt
2. Commit til GitHub
3. Railway auto-deployer

### Tilføj Nye Endpoints

1. Rediger `app.py`
2. Tilføj ny route
3. Test lokalt
4. Deploy til Railway
5. Opdater Retool queries

## 💰 Omkostninger

- **Railway Hobby:** $5/måned
- **Railway Pro:** $20/måned (hvis mere trafik)

## 📝 License

Private - Creative Space internal use only.

---

**Bygget med ❤️ for Creative Space**

Dashboard til at tracke PAX, belægningsgrad, omsætning og lønudgifter på tværs af alle 6 lokationer.
